<?php
// Start the session
    session_start();
    include("connect.php"); ?>